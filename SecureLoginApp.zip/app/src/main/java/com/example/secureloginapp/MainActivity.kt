package com.example.secureloginapp

import android.content.Context
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import android.widget.Toast
import com.example.secureloginapp.databinding.ActivityMainBinding
import at.favre.lib.crypto.bcrypt.BCrypt
import java.security.MessageDigest
import java.util.concurrent.Executor

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var executor: Executor
    private lateinit var biometricPrompt: BiometricPrompt
    private lateinit var promptInfo: BiometricPrompt.PromptInfo

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val masterKey = MasterKey.Builder(this)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        val sharedPreferences = EncryptedSharedPreferences.create(
            this,
            "secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )

        executor = ContextCompat.getMainExecutor(this)
        biometricPrompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                Toast.makeText(applicationContext, "Sikeres ujjlenyomat azonosítás!", Toast.LENGTH_SHORT).show()
            }
        })

        promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Ujjlenyomat hitelesítés")
            .setNegativeButtonText("Mégse")
            .build()

        binding.registerButton.setOnClickListener {
            val input = binding.passwordInput.text.toString()
            val hash = tripleHash(input)
            sharedPreferences.edit().putString("user_hash", hash).apply()
            Toast.makeText(this, "Regisztráció sikeres!", Toast.LENGTH_SHORT).show()
        }

        binding.loginButton.setOnClickListener {
            val input = binding.passwordInput.text.toString()
            val storedHash = sharedPreferences.getString("user_hash", null)
            if (storedHash != null && BCrypt.verifyer().verify(tripleHashRaw(input).toCharArray(), storedHash).verified) {
                Toast.makeText(this, "Sikeres bejelentkezés!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Hibás jelszó!", Toast.LENGTH_SHORT).show()
            }
        }

        binding.biometricButton.setOnClickListener {
            biometricPrompt.authenticate(promptInfo)
        }
    }

    private fun tripleHashRaw(input: String): String {
        val sha256 = MessageDigest.getInstance("SHA-256")
        val sha3 = MessageDigest.getInstance("SHA3-512")
        val first = sha256.digest(input.toByteArray()).joinToString("") { "%02x".format(it) }
        val second = sha3.digest(first.toByteArray()).joinToString("") { "%02x".format(it) }
        return second
    }

    private fun tripleHash(input: String): String {
        return BCrypt.withDefaults().hashToString(12, tripleHashRaw(input).toCharArray())
    }
}
